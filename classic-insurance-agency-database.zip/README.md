# Classic Agent Backend — Starter

This replaces the prototype's browser-based `window.storage` calls with a real,
persistent database and API. It's a starting point, not a finished production
system — treat it as the skeleton to build on.

## What this is

- **`schema.sql`** — the real Postgres tables: `leads`, `lead_documents`, `lead_messages`.
- **`server.js`** — a small Express API: create/update/list leads, log chat messages,
  and trigger a QQCatalyst sync.
- **`qqcatalyst.js`** — a stub for pushing leads into QQCatalyst. Left unimplemented
  on purpose since it needs real API partner credentials first (see the architecture
  plan, Section 5.2 — registration with QQ Solutions isn't self-serve).
- **`db.js`** — the Postgres connection.

## What this is *not*

- Not hosted. This code needs to run somewhere that stays on 24/7 — it doesn't
  run itself. Realistic options for a business this size: Render, Railway, or
  Supabase (which can host both the Postgres database *and* the API).
- Not secured beyond the basics. No authentication is implemented on the
  `/api/leads` GET endpoint yet — before this is real, that needs to be locked
  down so only staff can view it (e.g., an API key or login, not a public URL).
- Not connected to file/document storage yet. `lead_documents` stores a URL —
  actually uploading and storing the files (e.g., to S3) is a separate piece.

## Getting it running

1. Create a Postgres database on a managed host (Supabase's free tier is the
   easiest starting point for a small agency).
2. Copy `.env.example` to `.env` and fill in `DATABASE_URL`.
3. Install dependencies and run the migration:
   ```
   npm install
   npm run migrate
   ```
4. Start the server:
   ```
   npm start
   ```
5. Deploy it somewhere that stays running (Render/Railway both have simple
   "connect a repo, deploy" flows for a small Express app like this one).

## Connecting the website to this instead of `window.storage`

In the website prototype, `saveLeadRecord()` currently calls `window.storage.set(...)`.
Once this backend is deployed, that function gets replaced with a `fetch()` call to
`POST /api/leads` on this API instead — same shape of data, different destination.
Happy to make that swap in the website file once this backend has a real deployed URL.

## Filling in QQCatalyst

Once Classic has API partner credentials from QQ Solutions, `qqcatalyst.js` needs
the OAuth2 token exchange and the actual field mapping from `lead.fields` to
whatever QQCatalyst's contact/lead endpoint expects — that mapping depends on
the partner API docs, which arrive after registration approval.
