require('dotenv').config();
const express = require('express');
const cors = require('cors');
const pool = require('./db');
const { syncLeadToQQCatalyst } = require('./qqcatalyst');

const app = express();
app.use(cors());
app.use(express.json({ limit: '2mb' }));

// Create a new lead — called by the chat widget when it captures a
// lead-summary, or by the dealership inquiry form.
app.post('/api/leads', async (req, res) => {
  const { type, fields } = req.body;
  if (!type || !fields) return res.status(400).json({ error: 'type and fields are required' });
  try {
    const result = await pool.query(
      `insert into leads (type, fields) values ($1, $2) returning *`,
      [type, fields]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error('[POST /api/leads]', err);
    res.status(500).json({ error: 'Could not save lead' });
  }
});

// Update a lead's stage (onboarding_complete, paid) and/or merge new fields.
app.patch('/api/leads/:id', async (req, res) => {
  const { stage, fields } = req.body;
  try {
    const result = await pool.query(
      `update leads
       set stage = coalesce($1, stage),
           fields = case when $2::jsonb is not null then fields || $2::jsonb else fields end,
           updated_at = now()
       where id = $3
       returning *`,
      [stage || null, fields ? JSON.stringify(fields) : null, req.params.id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Lead not found' });
    res.json(result.rows[0]);
  } catch (err) {
    console.error('[PATCH /api/leads/:id]', err);
    res.status(500).json({ error: 'Could not update lead' });
  }
});

// Staff view — list recent leads.
app.get('/api/leads', async (req, res) => {
  try {
    const result = await pool.query(`select * from leads order by created_at desc limit 200`);
    res.json(result.rows);
  } catch (err) {
    console.error('[GET /api/leads]', err);
    res.status(500).json({ error: 'Could not load leads' });
  }
});

// Append a chat message to a lead's transcript (optional, for audit trail).
app.post('/api/leads/:id/messages', async (req, res) => {
  const { role, content } = req.body;
  try {
    const result = await pool.query(
      `insert into lead_messages (lead_id, role, content) values ($1, $2, $3) returning *`,
      [req.params.id, role, content]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error('[POST /api/leads/:id/messages]', err);
    res.status(500).json({ error: 'Could not save message' });
  }
});

// Push a lead into QQCatalyst once API partner credentials exist.
app.post('/api/leads/:id/sync-qqcatalyst', async (req, res) => {
  try {
    const result = await pool.query(`select * from leads where id = $1`, [req.params.id]);
    const lead = result.rows[0];
    if (!lead) return res.status(404).json({ error: 'Lead not found' });
    const syncResult = await syncLeadToQQCatalyst(lead);
    if (syncResult.synced) {
      await pool.query(
        `update leads set qqcatalyst_synced = true, qqcatalyst_record_id = $1 where id = $2`,
        [syncResult.recordId, lead.id]
      );
    }
    res.json(syncResult);
  } catch (err) {
    console.error('[POST /api/leads/:id/sync-qqcatalyst]', err);
    res.status(500).json({ error: 'Sync failed' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Backend listening on port ${PORT}`));
