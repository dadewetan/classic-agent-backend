const { Pool } = require('pg');

// DATABASE_URL comes from whichever managed Postgres host is chosen
// (Supabase, Render, Railway, AWS RDS...). SSL is required by most
// managed hosts but not local dev, hence the localhost check.
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL && !process.env.DATABASE_URL.includes('localhost')
    ? { rejectUnauthorized: false }
    : false,
});

module.exports = pool;
